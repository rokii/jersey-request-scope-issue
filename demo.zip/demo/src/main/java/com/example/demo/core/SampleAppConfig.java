package com.example.demo.core;

import org.springframework.context.annotation.Configuration;

import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.LinkedHashSet;
import java.util.Set;

@Configuration
@ApplicationPath("v1")
public class SampleAppConfig extends Application {

    @Inject
    MyFilter myFilter;

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> providers = new LinkedHashSet<Class<?>>();
        providers.add(HelloService.class);
        return providers;
    }

    @Override
    public Set<Object> getSingletons() {
        Set<Object> providers = new LinkedHashSet<Object>();
        providers.add(myFilter);
        return providers;
    }
}
