package com.example.demo.config;


import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.glassfish.jersey.CommonProperties;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.jersey.JerseyProperties;
import org.springframework.boot.autoconfigure.jersey.ResourceConfigCustomizer;
import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ClassUtils;
import org.springframework.web.filter.RequestContextFilter;


@Configuration
@ConditionalOnClass(name = { "org.glassfish.jersey.server.spring.SpringComponentProvider",
        "javax.servlet.ServletRegistration" })
@ConditionalOnWebApplication
@AutoConfigureOrder(Ordered.HIGHEST_PRECEDENCE + 1)
@AutoConfigureBefore(DispatcherServletAutoConfiguration.class)
@EnableConfigurationProperties(JerseyProperties.class)
public class JerseyApplicationsAutoconfig implements ServletContextInitializer {

    private static final Logger logger = LoggerFactory.getLogger(JerseyApplicationsAutoconfig.class);

    private final JerseyProperties jersey;

    private final List<Application> jaxAppList;


    public JerseyApplicationsAutoconfig(JerseyProperties jersey, List<Application> config) {
        if (config == null || config.isEmpty()) {
            throw new IllegalArgumentException("Application can't be null!");
        }

        this.jersey = jersey;
        this.jaxAppList = config;
    }

    protected String findApplicationPath(ApplicationPath annotation) {
        // Jersey doesn't like to be the default servlet, so map to /* as a fallback
        if (annotation == null) {
            return null;
        }

        String applicationPath = annotation.value();
        if (!applicationPath.startsWith("/")) {
            applicationPath = "/" + applicationPath;
        }

        if (!applicationPath.endsWith("/*")) {
            if (applicationPath.endsWith("/")) {
                applicationPath = applicationPath + "*";
            } else {
                applicationPath = applicationPath + "/*";
            }
        }

        return applicationPath;
    }

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        setServletContext(servletContext);
    }

    @Bean
    @ConditionalOnMissingBean
    public FilterRegistrationBean serverRequestContextFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new RequestContextFilter());
        registration.setOrder(this.jersey.getFilter().getOrder() - 1);
        registration.setName("requestContextFilter");
        return registration;
    }

    protected void registerServletMapping(Application jaxrsApp, Dynamic servletReg) {
        String mappingPath = findApplicationPath(AnnotationUtils.findAnnotation(jaxrsApp.getClass(), ApplicationPath.class));
        if (mappingPath != null) {
            if (logger.isInfoEnabled()) {
                logger.info("Adding servlet with Path: " + mappingPath);
            }
            servletReg.addMapping(mappingPath);
        }
    }


    private void setServletContext(ServletContext servletContext) {
        for (Application jaxrsApp : jaxAppList) {
            final ResourceConfig resourceConfig = ResourceConfig.forApplication(jaxrsApp);

            Dynamic servletReg = servletContext.addServlet(ClassUtils.getUserClass(jaxrsApp.getClass()).getName(),
                    new ServletContainer(resourceConfig));
            if (servletReg != null) {
                servletReg.setInitParameters(jersey.getInit());
                servletReg.setInitParameter(CommonProperties.METAINF_SERVICES_LOOKUP_DISABLE, Boolean.TRUE.toString());
                servletReg.setAsyncSupported(true);

                registerServletMapping(jaxrsApp, servletReg);
            }
        }
    }

}