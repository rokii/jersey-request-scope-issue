package com.example.demo.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

@Provider
@Component
public class MyFilter implements ContainerRequestFilter{


    HttpServletRequest request;

    @Context
    private void setRequest(HttpServletRequest request){
        this.request = request;
    }


    @Override
    public void filter(ContainerRequestContext containerRequestContext) throws IOException {

        System.out.println("one header" + request.getHeaderNames().nextElement());
    }
}
