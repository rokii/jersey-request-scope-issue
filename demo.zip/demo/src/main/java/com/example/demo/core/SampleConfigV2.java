//package com.example.demo;
//
//import org.glassfish.jersey.server.ResourceConfig;
//import org.springframework.context.annotation.Configuration;
//
//import javax.ws.rs.ApplicationPath;
//
//@Configuration
//@ApplicationPath("/v2")
//public class SampleConfigV2 extends ResourceConfig {
//
//    public SampleConfigV2(){
//        register(MyFilter.class);
//        register(HelloService.class);
//    }
//}