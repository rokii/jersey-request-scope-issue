package com.example.demo.core;

import org.springframework.stereotype.Component;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/test")
@Component
public class HelloService {

    @GET
    @Produces("text/plain")
    @Path("/hello")
    public String hello() {
        return "Hello from Spring";
    }
}
