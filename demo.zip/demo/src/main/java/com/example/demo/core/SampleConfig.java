//package com.example.demo;
//
//import org.glassfish.jersey.server.ResourceConfig;
//import org.springframework.context.annotation.Configuration;
//
//import javax.ws.rs.ApplicationPath;
//
//@Configuration
//@ApplicationPath("/v1")
//public class SampleConfig extends ResourceConfig {
//
//    public SampleConfig(){
//        register(MyFilter.class);
//        register(HelloService.class);
//    }
//}